import UIKit

struct engines {
    var engineMotorOption1 = ""
    var engineMotorOption2 = ""
    var engineMotorOption3 = ""
     
    
    func Totalengines() -> String {
        return " I have 3 Motor Engine Options:" + engineMotorOption1 + " " + engineMotorOption2 + " "
        + engineMotorOption3
    }
}
var enginePicked = engines (engineMotorOption1: " R8 V10," , engineMotorOption2: " 700hp Twin Turbo RB26," , engineMotorOption3: " V8 Twin Turbo ")

enginePicked.Totalengines()
print(enginePicked.Totalengines())
